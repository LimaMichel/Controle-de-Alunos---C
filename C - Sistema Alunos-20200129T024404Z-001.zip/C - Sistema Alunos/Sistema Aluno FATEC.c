#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct{
int gravv;
char nome[100];
char ra[10];
char curso[100];
}tes; //minha estrutura

int main (void)
{

tes a,b,c;

char grav[100],arquivo[100],pesquisa[100];
int op,senha,exibir,pos;
int show[50];
FILE *arq;

printf("---Bem-vindo ao Sistema cadastro de alunos FATEC---\n\n");
s:
printf("\nDigite a senha de 3 digitos para acesso: ");
scanf("%d",&senha);

       if(senha==123)
        {
        system("cls");
        a:


        printf("\n\nEscolha uma das operacoes:\n--------------------------\n");
        printf("1 - Inserir\n 2 - Consultar \n 3 - Exibir \n 4 - Sair\n\n:");
        scanf("%d",&op);


        switch(op){

          case 1:
              if ((arq = fopen ("Cadastro", "wb"))== NULL )
                {
                  printf (" N�o foi possivel abrir o arquivo Cadastro");
                  exit(1);
                } //testa se o arquivo existe

       do{
         printf("\nDigite um Codigo:\n: "); //codigo comeca do zero
         fflush(stdin);
         gets(grav);
         a.gravv=atoi(grav);

         printf("\nDigite o Nome:\n ");
         fflush(stdin);
         gets(a.nome);

         printf("\nDigite o RA:\n ");
         fflush(stdin);
         gets(a.ra);

         printf("\nDigite o Curso:\n ");
         fflush(stdin);
         gets(a.curso);

         fwrite(&a, sizeof(tes),1, arq);
         printf("\nDeseja adicionar outro registro no arquivo ? tecla 'S' (sim) ou 'N' (nao)\n:");
         }while(getche() =='s');
         fclose(arq);
       goto a;

       break;

        case 2:
            if ((arq = fopen ("Cadastro", "rb"))== NULL )
                {
                  printf (" N�o foi possivel abrir o arquivo cadastro");
                  exit(1);
                }
            printf("\nDigite a posicao do resgistro (ponteiro)\n:");
            fflush(stdin);
            scanf("%d",&pos);
            getchar();
            fseek(arq,sizeof(tes)*(pos-1),SEEK_SET);

           if(ferror(arq))
            {
            printf("\nErro de posicao do ponteiro\n");
            }

           else
            {
             fread(&c,sizeof(tes),1,arq);
                if(ferror(arq))
                {
                   printf("\nErro na leitura do aquivo\n");
                }
            else
             {
              printf("\nO cadastro esta no arquivo:");
              printf("\n Codigo: %d\n Nome: %s\nRA: %s\nCurso: %s\n",c.gravv,c.nome);
             }
            }

          fclose(arq);

          goto a;
          break;

        case 3:
            if ((arq = fopen ("Cadastro", "rb"))== NULL )
                {
                 printf (" N�o foi possivel abrir o arquivo cadastro");
                 exit(1);
                }
            else
              {
                printf("Conteudo do arquivo:\n ");
                rewind(arq);

            do{
                printf("\nCodigo: %d\nNome: %s\nRA: %s\nCurso: %d",b.gravv,b.nome,b.ra,b.curso);
            }while(fread(&b,sizeof(tes),1,arq)==1);}

                 fclose(arq);

                 goto a;
                 break;

        case 4:
          fclose(arq);
          exit(0);
          break;

        default:
         printf("\nOpcao invalida\n");
         goto a;
         break;

        }//fecha menu (switch)

 }//fecha if

 else
    {
     system("cls");
     printf("\nSenha incorreta\n");
     goto s;
    }//teste de senha

    fclose(arq); //fecha arquivo

    system("pause");

}//fecha main

